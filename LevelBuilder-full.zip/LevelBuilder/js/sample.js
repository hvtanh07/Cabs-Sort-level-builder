/* Sample level copied from demo.json; loaded on first run only */
window.CS_SAMPLE_LEVEL = {
  "$schema": "../../../../../docs/design/level.schema.json",
  "formatVersion": 4,
  "id": "level_0033",
  "conveyor": "square_42",
  "slots": 4,
  "extraSlots": 2,
  "slotLocks": [{ "slot": 0, "lockTurns": 3 }],
  "trayCapacity": 4,
  "colors": [1, 2, 3, 4, 5, 6, 7, 8],
  "feeders": [
    { "bottles": [
      8, 8, 8, 8,
      2, 2, 2, 2,
      1, 1, 1, 1,
      5, 5, 5, 5,
      5, 5, 5, 5,
      6, 6, 6, 6,
      6, 6, 6, 6,
      6, 6, 6, 6,
      3, 3, 3, 3,
      3, 3, 3, 3,
      4, 4, 4, 4,
      4, 4, 4, 4,
      2, 2, 2, 2,
      2, 2, 2, 2,
      3, 3, 3, 3,
      3, 3, 3, 3,
      3, 3, 3, 3,
      3, 3, 3, 3,
      7, 7, 7, 7,
      7, 7, 7, 7,
      5, 5, 5, 5,
      5, 5, 5, 5,
      2, 2, 2, 2,
      6, 6, 6, 6,
      1, 1, 1, 1,
      4, 4, 4, 4
    ], "hiddenRows": [11, 14, 15, 16] },
    { "bottles": [
      4, 4, 4, 4,
      8, 8, 8, 8,
      8, 8, 8, 8,
      2, 2, 2, 2,
      6, 6, 6, 6,
      2, 2, 2, 2,
      8, 8, 8, 8,
      7, 7, 7, 7,
      7, 7, 7, 7,
      7, 7, 7, 7,
      8, 8, 8, 8,
      4, 4, 4, 4,
      4, 4, 4, 4,
      6, 6, 6, 6,
      1, 1, 1, 1,
      1, 1, 1, 1,
      1, 1, 1, 1,
      1, 1, 1, 1,
      5, 5, 5, 5,
      5, 5, 5, 5,
      8, 8, 8, 8,
      7, 7, 7, 7
    ], "hiddenRows": [3, 18], "lockedRows": [{ "row": 2, "lockTurns": 3 }, { "row": 4, "lockTurns": 5 }] }
  ],
  "lanes": [
    [{ "color": 8 }, { "color": 5 }, { "color": 2 }, { "color": 6 }, { "color": 4 }, { "color": 8 }, { "color": 5, "lockTurns": 4 }, { "color": 1 }, { "color": 4 }, { "color": 4 }, { "color": 2 }],
    [{ "color": 1, "size": 4 }, { "color": 6 }, { "color": 5 }, { "color": 8 }, { "color": 8 }, { "color": 7 }, { "color": 4 }, { "color": 3 }, { "color": 6 }],
    [{ "color": 4 }, { "color": 3, "hidden": true, "size": 3 }, { "color": 7, "hidden": true, "size": 3 }, { "color": 8 }, { "color": 2, "hidden": true }, { "color": 2 }, { "color": 8 }, { "color": 6 }],
    [{ "color": 2, "lockTurns": 4 }, { "color": 3 }, { "color": 6, "size": 2 }, { "color": 4 }, { "color": 5 }, { "color": 5 }, { "color": 1 }, { "color": 7 }, { "color": 2 }, { "color": 3, "lockTurns": 5 }, { "color": 5, "hidden": true }, { "color": 7 }]
  ],
  "links": [
    { "a": { "lane": 0, "tray": 4 }, "b": { "lane": 3, "tray": 6 } }
  ],
  "view": { "cameraPreset": "default" },
  "meta": { "name": "Square Maze", "difficulty": "hard" }
}
;
